// COMP2811 Coursework 1: QuakeDataset class
