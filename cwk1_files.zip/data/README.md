# COMP2811 Coursework 1

## Sample Data

This directory contains CSV files of earthquake data, for testing the
`quaketool` application. The original source of the data is the
[USGS Earthquake Hazards Program][usgs].

**NOTE:**

Do NOT rename or move this directory, or any of its files!

Doing so may break the tests for the `Quake` & `QuakeDataset` classes.


[usgs]: https://earthquake.usgs.gov/earthquakes/feed/v1.0/csv.php
