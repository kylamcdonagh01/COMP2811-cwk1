// COMP2811 Coursework 1: quaketool application

int main(int argc, char* argv[])
{
  return 0;
}
